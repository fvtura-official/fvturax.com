export { default as Main } from './Main';
export { default as Fluid } from './Fluid';
export { default as Fixed } from './Fixed';
