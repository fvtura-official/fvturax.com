export { default } from './Fixed';
