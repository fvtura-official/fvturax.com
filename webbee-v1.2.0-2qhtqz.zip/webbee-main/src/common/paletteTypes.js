const palettes = ['green', 'blue', 'indigo', 'pink', 'orange'];

export default palettes;
