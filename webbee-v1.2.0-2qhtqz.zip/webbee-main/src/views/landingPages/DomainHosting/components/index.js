export { default as About } from './About';
export { default as CallToAction } from './CallToAction';
export { default as Hero } from './Hero';
export { default as HowItWorks } from './HowItWorks';
export { default as Numbers } from './Numbers';
export { default as Pricing } from './Pricing';
export { default as Solutions } from './Solutions';
