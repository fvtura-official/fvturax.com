export { default as About } from './About';
export { default as Destinations } from './Destinations';
export { default as Form } from './Form';
export { default as Gallery } from './Gallery';
export { default as Hero } from './Hero';
export { default as Services } from './Services';
