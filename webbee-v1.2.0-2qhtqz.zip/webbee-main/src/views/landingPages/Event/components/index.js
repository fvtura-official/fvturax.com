export { default as About } from './About';
export { default as Hero } from './Hero';
export { default as Numbers } from './Numbers';
export { default as Registration } from './Registration';
export { default as Reviews } from './Reviews';
export { default as Schedules } from './Schedules';
export { default as Speakers } from './Speakers';
