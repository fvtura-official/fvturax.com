export { default as About } from './About';
export { default as Hero } from './Hero';
export { default as Features } from './Features';
export { default as PremiumFeatures } from './PremiumFeatures';
export { default as Reviews } from './Reviews';
export { default as Partners } from './Partners';
