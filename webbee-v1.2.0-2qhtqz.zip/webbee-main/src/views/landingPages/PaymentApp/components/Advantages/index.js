export { default } from './Advantages';
