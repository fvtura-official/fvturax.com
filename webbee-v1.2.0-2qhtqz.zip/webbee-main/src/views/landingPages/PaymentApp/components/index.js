export { default as CtaSection } from './CtaSection';
export { default as Features } from './Features';
export { default as Advantages } from './Advantages';
export { default as Hero } from './Hero';
export { default as HowItWorks } from './HowItWorks';
export { default as Partners } from './Partners';
export { default as Platforms } from './Platforms';
export { default as Reviews } from './Reviews';
