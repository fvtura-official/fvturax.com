export { default as Hero } from './Hero';
export { default as Benefits } from './Benefits';
export { default as ReviewSection } from './ReviewSection';
export { default as Platforms } from './Platforms';
export { default as Pricing } from './Pricing';
