export { default } from './Pricing';
