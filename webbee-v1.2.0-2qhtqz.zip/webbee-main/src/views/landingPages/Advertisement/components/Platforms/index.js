export { default } from './Platforms';
