export { default as Extensions } from './Extensions';
export { default as Features } from './Features';
export { default as Footer } from './Footer';
export { default as Hero } from './Hero';
export { default as Pricing } from './Pricing';
export { default as Reviews } from './Reviews';
