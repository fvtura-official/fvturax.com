export { default as Hero } from './Hero';
export { default as Reviews } from './Reviews';
export { default as Services } from './Services';
export { default as Features } from './Features';
export { default as Process } from './Process';
export { default as Team } from './Team';
export { default as Teaser } from './Teaser';
