export { default } from './Faq';
