export { default as Hero } from './Hero';
export { default as About } from './About';
export { default as ContactForm } from './ContactForm';
export { default as Faq } from './Faq';
export { default as Footer } from './Footer';
export { default as Overview } from './Overview';
export { default as Reviews } from './Reviews';
