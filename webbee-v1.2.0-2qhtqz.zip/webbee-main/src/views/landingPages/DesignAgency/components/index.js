export { default as Contact } from './Contact';
export { default as Hero } from './Hero';
export { default as Main } from './Main';
export { default as Partners } from './Partners';
export { default as Services } from './Services';
export { default as WhyUs } from './WhyUs';
export { default as Process } from './Process';
export { default as Reviews } from './Reviews';
