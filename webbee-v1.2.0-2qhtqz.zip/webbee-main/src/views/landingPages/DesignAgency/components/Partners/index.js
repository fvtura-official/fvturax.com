export { default } from './Partners';
