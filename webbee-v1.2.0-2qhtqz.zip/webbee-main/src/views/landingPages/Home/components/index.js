export { default as DemoPages } from './DemoPages';
export { default as Features } from './Features';
export { default as Footer } from './Footer';
export { default as Hero } from './Hero';
export { default as Highlights } from './Highlights';
