export { default } from './WhitePaper';
