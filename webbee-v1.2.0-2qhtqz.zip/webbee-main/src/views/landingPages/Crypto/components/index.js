export { default as About } from './About';
export { default as Download } from './Download';
export { default as Features } from './Features';
export { default as Hero } from './Hero';
export { default as Roadmap } from './Roadmap';
export { default as Team } from './Team';
export { default as WhitePaper } from './WhitePaper';
