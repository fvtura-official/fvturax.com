export { default as About } from './About';
export { default as Features } from './Features';
export { default as Hero } from './Hero';
export { default as News } from './News';
export { default as Partners } from './Partners';
export { default as Pricing } from './Pricing';
export { default as Subscription } from './Subscription';
