export { default } from './News';
