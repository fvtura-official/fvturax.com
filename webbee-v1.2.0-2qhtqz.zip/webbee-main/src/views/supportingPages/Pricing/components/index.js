export { default as Faq } from './Faq';
export { default as Partners } from './Partners';
export { default as PricingCards } from './PricingCards';
export { default as PricingCompareTable } from './PricingCompareTable';
