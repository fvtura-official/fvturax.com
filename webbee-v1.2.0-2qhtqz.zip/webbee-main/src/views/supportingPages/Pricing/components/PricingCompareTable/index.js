export { default } from './PricingCompareTable';
