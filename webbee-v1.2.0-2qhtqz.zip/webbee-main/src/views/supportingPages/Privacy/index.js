export { default } from './Privacy';
