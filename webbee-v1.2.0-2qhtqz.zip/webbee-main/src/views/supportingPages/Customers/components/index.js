export { default as Contact } from './Contact';
export { default as Headline } from './Headline';
export { default as Partners } from './Partners';
export { default as Stories } from './Stories';
