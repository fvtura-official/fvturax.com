export { default as Gallery } from './Gallery';
export { default as Headline } from './Headline';
export { default as Numbers } from './Numbers';
export { default as Story } from './Story';
export { default as Team } from './Team';
