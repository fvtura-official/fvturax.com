export { default as Contact } from './Contact';
export { default as Hero } from './Hero';
export { default as Process } from './Process';
export { default as Reviews } from './Reviews';
export { default as SeenOn } from './SeenOn';
export { default as WhatWeDo } from './WhatWeDo';
