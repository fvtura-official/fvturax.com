export { default } from './HireUs';
