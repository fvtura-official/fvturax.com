export { default } from './TypographyComponent';
