export { default } from './Illustrations';
