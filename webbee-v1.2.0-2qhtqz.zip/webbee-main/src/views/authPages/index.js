export { default as Login } from './Login';
export { default as LoginSimple } from './LoginSimple';
export { default as Signup } from './Signup';
export { default as SignupSimple } from './SignupSimple';
export { default as ForgotPassword } from './ForgotPassword';
export { default as ForgotPasswordSimple } from './ForgotPasswordSimple';
