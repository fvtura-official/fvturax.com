export { default } from './ForgotPasswordSimple';
