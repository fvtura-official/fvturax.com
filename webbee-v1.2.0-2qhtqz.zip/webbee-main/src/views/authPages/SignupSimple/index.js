export { default } from './SignupSimple';
